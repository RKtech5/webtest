<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"

"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<title>Feedback Report</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<style type="text/css">

<!--

.style1 {color: #FF0000}

.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}

.style3 {color: #000000}

.style4 {
font-family: Geneva, Arial, Helvetica, sans-serif;
font-weight: bold;
font-size: 16px;
color: #FFFFFF;
}

.style6 {
font-family: Georgia, "Times New Roman", Times, serif;
font-size: 14px;
font-weight: bold;
}

.style7 {font-family: Geneva, Arial, Helvetica, sans-serif}

.style8 {

	font-size: 11px;

	color: #000000;

}

.style9 {

	font-family: Geneva, Arial, Helvetica, sans-serif;

	font-size: 11px;

	color: #000000;

}

-->

</style>

</head>



<body topmargin="0" bottommargin="0">

<table width="100%"  border="0" cellspacing="0" cellpadding="0">

  <tr>

    <td height="350"><div align="center">

      <table width="98%"  border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#0099FF">

        <tr>

          <td height="30" bgcolor="#0099FF"><div align="center" class="style4">

              <div align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Customer Enquiry Report </div>

          </div></td>

        </tr>

        <tr>

          <td><div align="center">

              <table width="100%"  border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="20"><div align="center"><span class="style30 style1 style6">Thanks for your <span class="style25"><strong>specific/ customized requirements</strong></span></span></div></td>

                </tr>

                <tr>

                  <td><div align="center" class="style7 style8">

                      <?php 







$nameis = $_POST['name']; 

$address = $_POST['address'];

$city = $_POST['city'];

$state = $_POST['state'];

//$area = $_POST['area'];

$country = $_POST['country'];

$visitormail = $_POST['email']; 

$mobile = $_POST['mobile'];

$feedback = $_POST['description']; 

$to ="ganapathiengineering@gmail.com,mail@ganapathi.net.in,admin@ganapathi.net.in";

//$todayis = date("l, F j, Y, g:i a")    ;



//$feedback = stripcslashes($feedback);

//$message = " $todayis [EST] \n 

$message="From: $nameis ($visitormail)\n

Customized Requirements: $feedback \n  ";

$msg ="
		<table style=\" width:620px; float:left; border:1px solid green;\" cellpadding=\"0\" cellspacing=\"0\">
		<tr style=\" width:620px; background:url('http://mpetcontainers.com/images/menubg_hover.png') repeat-x; border-top-left-radius:10px; border-top-right-radius:10px;\">
			<h3 align=\"center\" style=\"color:black;\">Enquiry From $nameis</h3>
		</tr>
		
		<tr style=\"width:350px; margin-top:20px; float:left; padding:10px; margin-left:130px; margin-bottom:20px; border:1px solid #bdbdbd; border-radius:10px; \">
			<div  style=\"width:350px; float:left; margin-bottom:10px;\">
				<div style=\"width:150px; color:black; font-weight:bold; float:left;\">Contact Person</div>	
				<div style=\"width:10px; float:left; margin-left:10px;\">:</div>   
				<div style=\"width:180px; float:left;\">$nameis</div>
			</div>
			
		 
			
			<div style=\"width:350px; float:left; margin-bottom:10px;\">
				<div style=\"width:150px; color:black; font-weight:bold; float:left;\">Email	</div>	
				<div style=\"width:10px; float:left; margin-left:10px;\">:</div>   
				<div style=\"width:180px; float:left;\">$visitormail </div>
			</div>
			
			<div style=\"width:350px; float:left; margin-bottom:10px;\">
				<div style=\"width:150px; color:black; font-weight:bold; float:left;\">Address	</div>	
				<div style=\"width:10px; float:left; margin-left:10px;\">:</div>   
				<div style=\"width:180px; float:left;\">$address </div>
			</div>
			
			<div style=\"width:350px; float:left; margin-bottom:10px;\">
				<div style=\"width:150px; color:black; font-weight:bold; float:left;\">City	</div>	
				<div style=\"width:10px; float:left; margin-left:10px;\">:</div>   
				<div style=\"width:180px; float:left;\">$city </div>
			</div>
			
			<div style=\"width:350px; float:left; margin-bottom:10px;\">
				<div style=\"width:150px; color:black; font-weight:bold; float:left;\">State	</div>	
				<div style=\"width:10px; float:left; margin-left:10px;\">:</div>   
				<div style=\"width:180px; float:left;\">$state </div>
			</div>
			
			<div style=\"width:350px; float:left; margin-bottom:10px;\">
				<div style=\"width:150px; color:black; font-weight:bold; float:left;\">India	</div>	
				<div style=\"width:10px; float:left; margin-left:10px;\">:</div>   
				<div style=\"width:180px; float:left;\">$country </div>
			</div>

			
			
			<div style=\"width:350px; float:left; margin-bottom:10px;\">
				<div style=\"width:150px; color:black; font-weight:bold; float:left;\">Mobile	</div>	
				<div style=\"width:10px; float:left; margin-left:10px;\">:</div>   
				<div style=\"width:180px; float:left;\">$mobile </div>
			</div>
			
			<div style=\"width:350px; float:left; margin-bottom:10px;\">
				<div style=\"width:150px; color:black; font-weight:bold; float:left;\">Comments	</div>	
				<div style=\"width:10px; float:left; margin-left:10px;\">:</div>   
				<div style=\"width:180px; float:left;\">$feedback </div>
			</div>
			
			
	   </tr>
	   </table>";




$subject = "Enquiry Send From $nameis\n";

$from="mail@mpetcontainers.com";
//$headers = "From: $visitormail\n";
$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From:".$from;



if(mail($to, $subject, $msg, $headers))

{?>
	<script>
	alert("sucessfully send");
	window.location.href="index.html";
	</script>
<?php 
}

else
{
	?>
		<script>
		alert("sending Failed");
		window.location.href="index.php";
		</script>
	<?php 
}









$screenout = str_replace("\n", "<br/>", $message);

?>

                  </div></td>

                </tr>

                <tr>

                  <td><div align="center" class="style9"><?php echo $screenout ?></div></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                  <td><div align="center">

                    <form name="form1" method="post" action="">

                      <input type="submit" name="Submit" value="Close" onClick="window.close()">

                    </form>

                  </div></td>

                </tr>

              </table>

              <h3 align="center" class="style30 style1">&nbsp;</h3>

              <span class="style2">

              <!-- VIP: change YourEmail to your real email -->

              </span>

              <div align="center"> <span class="style39 style2 style3"> </span></div>

              <p align="center">&nbsp; </p>

          </div></td>

        </tr>

      </table>

    </div></td>

  </tr>

</table>

</body>

</html>


